import { Component } from '@angular/core';

@Component({
  selector: 'app-feedback-info',
  templateUrl: './feedback-info.component.html',
  styleUrls: ['./feedback-info.component.css']
})
export class FeedbackInfoComponent {

}
