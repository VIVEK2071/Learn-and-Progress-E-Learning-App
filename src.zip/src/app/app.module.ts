import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EnrollmentInfoComponent } from './enrollment-info/enrollment-info.component';
import { TrainerInfoComponent } from './trainer-info/trainer-info.component';
import { CourseInfoComponent } from './course-info/course-info.component';
import { StudentInfoComponent } from './student-info/student-info.component';
import { FeedbackInfoComponent } from './feedback-info/feedback-info.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    EnrollmentInfoComponent,
    TrainerInfoComponent,
    CourseInfoComponent,
    StudentInfoComponent,
    FeedbackInfoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatSidenavModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
