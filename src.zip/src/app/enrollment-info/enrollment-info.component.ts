
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { EnrollmentService } from './enrollment.service';
import { NgForm } from '@angular/forms';
import { Enrollment } from './enrollment';

@Component({
  selector: 'app-enrollment-info',
  templateUrl: './enrollment-info.component.html',
  styleUrls: ['./enrollment-info.component.css']
})
export class EnrollmentInfoComponent implements OnInit {
  
  enroll:Enrollment=new Enrollment();
  myparam: number = 0;
  enrollments: any;
  responseMessage: string = '';
  updateScoreForm: any;
  enrollmentByIDForm: any;
  scoreCourseForm: any;
  courseForm: any;
  enroll1:Enrollment | undefined;
  // Form models for different operations
  enrolls!: Enrollment[];
  enrollsSorted!:Enrollment[];
  enrollMin!:Enrollment[];
  enrollMax!:Enrollment[];
  enrollmentId!:any;
  enrollUpdated:Enrollment|undefined;
 
  
  
  constructor(private enrollmentService: EnrollmentService,private route: ActivatedRoute) { }
  ngOnInit(): void {
    this.route.queryParams.subscribe((queryParams: { [x: string]: number; }) => {
      this.myparam = queryParams['paramFlag'] || 1; // Default to 1 if 'paramFlag' is not provided in the query parameters.
    });
    this.viewAll();
    this.viewScoreBySort();
    this.viewMaxScore();
    this.viewMinScore();
    

  }
  addEnrollment() {
    this.responseMessage="";
    this.enrollmentService.addEnrollment(this.enroll, this.enroll.studentId, this.enroll.trainerId, this.enroll.courseId)
      .subscribe(
        (response: any) => {
          this.responseMessage = `Enrollment with ID ${response.eId} added successfully`;
        },
        (error) => {
          this.responseMessage = 'An error occurred while adding the enrollment.';
        }
      );
  }
  updateScore() {
    this.responseMessage="";
    this.enrollmentService.updateScore(this.enroll.enrollmentId, this.enroll.score)
      .subscribe(
       
        (data) => {
          // Data validation successful
          this.responseMessage="Data successfully updated:",
          this.enrollUpdated = data as Enrollment;
        },
        (error: any) => {
          // Data validation failed
          this.responseMessage="Data is not updated:"
        }
      );
        

  }
  viewAll(){
    this.responseMessage="";
    this.enrollmentService.viewAll().subscribe(
      data=>{this.enrolls=data as Enrollment[]});
    
  }
  viewEnrollmentByID() {
    this.responseMessage="";
    this.enrollmentService.viewEnrollmentByID(this.enrollmentId)
      .subscribe(
        // () => {
        //   this.responseMessage = `Enrollment ID ${enrollmentID} details retrieved successfully`;
        //   // Handle enrollment data (enrollment) as needed
        // },
        // () => {
        //   this.responseMessage = `Enrollment ID ${enrollmentID} does not exist`;
        // }
        data => {
          
          this.enroll1=data as Enrollment;

        }
        
      );
  }
  viewMaxScore(){
    this.responseMessage="";
    this.enrollmentService.viewMaxScore().subscribe(
      data=>{this.enrollMax=data as Enrollment[]});
    
  }
  viewScoreBySort(){
    this.responseMessage="";
    this.enrollmentService.viewScoreBySort().subscribe(
      data=>{this.enrollsSorted=data as Enrollment[]});
    
  }
  viewMinScore() {
    this.responseMessage="";
    this.enrollmentService.viewMinScore().subscribe(
      data=>{this.enrollMin=data as Enrollment[]});
    
  }
  // viewEnrollmentByCourseId() {
  //   const courseID = this.courseForm.courseID;
  //   this.enrollmentService.viewEnrollmentByCourseId(courseID)
  //     .subscribe(
  //       (enrollments: any) => {
  //         this.enrollments = enrollments;
  //         this.responseMessage = 'View Enrollment by Course ID done successfully';
  //       },
  //       () => {
  //         this.enrollments = [];
  //         this.responseMessage = 'No enrollments found for the given Course ID';
  //       }
  //     );
  // }
}
