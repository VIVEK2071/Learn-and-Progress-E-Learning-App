export class Enrollment{
    enrollmentId:string="";
    startDate: Date | undefined;
    endDate: Date | undefined;
    score:number=0;
    status:string='';
    studentId:string="";
    trainerId:string="";
    courseId:string="";

}