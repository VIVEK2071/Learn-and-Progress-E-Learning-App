import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CourseInfoComponent } from './course-info/course-info.component';
import { EnrollmentInfoComponent } from './enrollment-info/enrollment-info.component';
import { FeedbackInfoComponent } from './feedback-info/feedback-info.component';
import { StudentInfoComponent } from './student-info/student-info.component';
import { TrainerInfoComponent } from './trainer-info/trainer-info.component';

const routes: Routes = [
 { path: '', redirectTo: '/trainerInfo', pathMatch: 'full' },
  { path: 'trainerInfo', component: TrainerInfoComponent },
  { path: 'courseInfo', component: CourseInfoComponent },
  { path: 'studentInfo', component: StudentInfoComponent },
  { path: 'enrollmentInfo', component: EnrollmentInfoComponent },
  { path: 'feedbackInfo', component: FeedbackInfoComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
